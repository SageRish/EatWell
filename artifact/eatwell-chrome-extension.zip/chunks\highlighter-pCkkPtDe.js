const d="eatwell-highlight",x="eatwell-highlighter-style",u="eatwell-highlighter-tooltip";function v(){if(document.getElementById(x))return;const e=document.createElement("style");e.id=x,e.textContent=`
    .${d} {
      background-color: rgba(255, 230, 128, 0.6);
      text-decoration: underline;
      text-decoration-color: rgba(255,120,0,0.9);
      border-radius: 2px;
      cursor: pointer;
    }
    .${d}[data-allergen] {
      box-shadow: inset 0 -2px 0 rgba(255,120,0,0.6);
    }
    #${u} {
      position: fixed;
      z-index: 2147483646; /* very high but below extension panels */
      background: rgba(33,33,33,0.95);
      color: white;
      padding: 8px 10px;
      border-radius: 6px;
      font-size: 13px;
      max-width: 320px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      pointer-events: none;
      transition: opacity 120ms ease-in-out;
      opacity: 0;
    }
    #${u}.visible { opacity: 1; pointer-events: auto; }
    #${u} .title { font-weight: 600; margin-bottom: 4px; }
    #${u} .sub { font-size: 12px; opacity: 0.95 }
  `,document.head.appendChild(e)}function w(){let e=document.getElementById(u);return e||(e=document.createElement("div"),e.id=u,e.setAttribute("role","tooltip"),e.innerHTML='<div class="title"></div><div class="sub"></div>',document.body.appendChild(e),e)}function E(e,n,r){const s=e.getBoundingClientRect(),l=window.innerWidth,o=window.innerHeight;let t=n+12,c=r+12;t+s.width+8>l&&(t=n-s.width-12),c+s.height+8>o&&(c=r-s.height-12),e.style.left=`${Math.max(6,t)}px`,e.style.top=`${Math.max(6,c)}px`}function y(e){if(!e||e.nodeType!==Node.TEXT_NODE)return!0;const n=e.parentElement;if(!n)return!0;const r=n.tagName.toLowerCase();return!!(["script","style","textarea","input"].includes(r)||n.isContentEditable)}function C(e,n,r,i){const s=document.createRange();s.setStart(e,n),s.setEnd(e,r);const l=document.createElement("span");l.className=d;for(const o in i)l.setAttribute(o,i[o]);try{s.surroundContents(l)}catch{const t=e.textContent||"",c=t.slice(0,n),a=t.slice(n,r),h=t.slice(r),m=document.createTextNode(c),f=document.createElement("span");f.className=d;for(const b in i)f.setAttribute(b,i[b]);f.textContent=a;const p=document.createTextNode(h),g=e.parentNode;if(!g)return;g.insertBefore(m,e),g.insertBefore(f,e),g.insertBefore(p,e),g.removeChild(e)}}function T(e,n,r){e.textContent;const i=n.trim();if(!i)return 0;let s=0;const l=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode(t){return y(t)||!t.nodeValue?NodeFilter.FILTER_REJECT:t.nodeValue.toLowerCase().includes(i.toLowerCase())?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}}),o=[];for(;l.nextNode();)o.push(l.currentNode);for(const t of o){const a=(t.nodeValue||"").toLowerCase().indexOf(i.toLowerCase());a>=0&&(C(t,a,a+i.length,r),s++)}return s}function L(e){v();const n=w();function r(o){const t=o.target;if(!t)return;const c=t.closest(`.${d}`);if(!c)return;const a=c.getAttribute("data-allergen")||"Allergen",h=c.getAttribute("data-substitute")||"No suggestion",m=n.querySelector(".title"),f=n.querySelector(".sub");m.textContent=a,f.textContent=`Suggested substitute: ${h}`,n.classList.add("visible");const p=o;E(n,p.clientX,p.clientY)}function i(o){const t=o.target;if(t&&t.closest?t.closest(`.${d}`):null){const a=o;E(n,a.clientX,a.clientY)}}function s(o){const t=o.target;t&&t.closest&&t.closest(`.${d}`)&&n.classList.remove("visible")}document.body.hasAttribute("data-eatwell-highlighter-listeners")||(document.addEventListener("mouseenter",r,!0),document.addEventListener("mousemove",i,!0),document.addEventListener("mouseleave",s,!0),document.body.setAttribute("data-eatwell-highlighter-listeners","1"));let l=0;for(const o of e){const t={"data-ingredient":o.ingredientText,"data-allergen":o.allergen,"data-substitute":o.substituteSuggested||""};if(o.selector){const c=Array.from(document.querySelectorAll(o.selector));for(const a of c)l+=T(a,o.ingredientText,t)}else l+=T(document.body,o.ingredientText,t)}return{highlighted:l}}function N(){const e=Array.from(document.querySelectorAll(`.${d}`));for(const r of e){const i=r.parentNode;if(!i)continue;const s=document.createTextNode(r.textContent||"");i.replaceChild(s,r)}const n=document.getElementById(u);n&&n.parentNode&&n.parentNode.removeChild(n)}export{N as clearHighlights,L as highlightDetections};
